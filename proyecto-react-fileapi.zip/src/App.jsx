import React from 'react'
import ImageUploader from './components/ImageUploader'

function App() {
  return (
    <div className="app">
      <h1>Subir y Mostrar Imagen con React + File API</h1>
      <ImageUploader />
    </div>
  )
}

export default App