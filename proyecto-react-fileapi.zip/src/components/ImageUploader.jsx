import React, { useState } from 'react'

function ImageUploader() {
  const [imageSrc, setImageSrc] = useState(null)
  const [error, setError] = useState(null)

  const handleFileChange = (event) => {
    const file = event.target.files[0]
    if (!file) {
      setError("No hay archivo seleccionado")
      setImageSrc(null)
      return
    }

    if (!file.type.startsWith("image/")) {
      setError("El archivo seleccionado no es una imagen")
      setImageSrc(null)
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      setImageSrc(e.target.result)
      setError(null)
    }
    reader.readAsDataURL(file)
  }

  return (
    <div>
      <input type="file" accept="image/*" onChange={handleFileChange} />
      {error && <p style={{ color: "red" }}>{error}</p>}
      {imageSrc && (
        <img
          src={imageSrc}
          alt="preview"
          style={{
            maxWidth: "400px",
            marginTop: "10px",
            border: "2px solid #ccc",
            borderRadius: "8px"
          }}
        />
      )}
    </div>
  )
}

export default ImageUploader