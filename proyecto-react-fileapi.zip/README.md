# Proyecto React: Subir y Mostrar Imagen con File API

Este proyecto es un ejemplo en **React + Vite** que permite subir un archivo, validar que sea una imagen y mostrarla en la página.

## 🚀 Instrucciones para ejecutar

1. Clonar este repositorio:
   ```bash
   git clone https://github.com/USERNAME/proyecto-react-fileapi.git
   cd proyecto-react-fileapi
   ```

2. Instalar dependencias:
   ```bash
   npm install
   ```

3. Iniciar servidor de desarrollo:
   ```bash
   npm run dev
   ```

4. Abrir en el navegador la URL que aparece (ejemplo: `http://localhost:5173`).

## 🛠 Tecnologías usadas
- React 18
- Vite
- JavaScript (File API)
